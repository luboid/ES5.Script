Copyright � Microsoft Corporation.  All rights reserved.

This posting is provided �AS IS� with no warranties of any kind and confers no rights.  Use of samples included in this posting are subject to the terms specified at http://www.microsoft.com/info/cpyright.htm.
